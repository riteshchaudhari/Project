package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import pojos.User;

public class Authenticate {
	
	Connection connection = DBManager.getConnection();
	

	public User authorise(User user) 
	{		
			Statement statement = null;
			ResultSet resultset = null;
			
			User user1 = null;
			System.out.println(user);
			try {

			statement = connection.createStatement();			
			
			resultset = statement.executeQuery("select * from book_review_sys.users where UEmail='"+user.getuEamil()+"' and UPassword=SHA1('"+user.getuPassword()+"')");	
			     
			if(resultset.next())
			{
				user1 = new User();
				user1.setUserId(resultset.getInt(1));
				user1.setuName(resultset.getString(2));
				user1.setuEamil(resultset.getString(3));
				user1.setuPassword(resultset.getString(4));
				user1.setuRole(resultset.getString(5));
			}
			
				
		
		
			
		} catch (SQLException e) {

			e.printStackTrace();
		} 		 
		
		return user1;
		
	}
	
	public boolean register (User user){
		
		try {
			PreparedStatement statement = connection.prepareStatement("insert into book_review_sys.users (UName,UEmail,UPassword,URole) values (?,?,SHA1(?),?)");  

			statement.setString(1,user.getuName());  
			statement.setString(2,user.getuEamil());  
			statement.setString(3,user.getuPassword());  
			statement.setString(4, "User");
			
			int rowAffected = statement.executeUpdate();
			if(rowAffected > 0)
				return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
}

