package controller;

import javax.servlet.ServletContext;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class ActiveUserListener
 *
 */
@WebListener
public class ActiveUserListener implements HttpSessionListener
{
	private static int userCount = 0;
	ServletContext context;
    public ActiveUserListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent event) 
    {    
         userCount++;
         context = event.getSession().getServletContext();
         context.setAttribute("userCount", userCount);
    }

	/**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent event)  
    { 
         userCount--;        
         context.setAttribute("userCount", userCount);
    }
	
}
