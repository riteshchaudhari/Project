package pojos;

public class User {
	
	private Integer userId;
	private String uName;
	private String uEamil;
	private String uPassword;
	private String uRole;

	public User() {
	}
	
	
	public User(String uName, String uEamil, String uPassword, String uRole) {
		super();
		this.uName = uName;
		this.uEamil = uEamil;
		this.uPassword = uPassword;
		this.uRole = uRole;
	}


	public User(Integer userId, String uName, String uEamil, String uPassword, String uRole) {
		super();
		this.userId = userId;
		this.uName = uName;
		this.uEamil = uEamil;
		this.uPassword = uPassword;
		this.uRole = uRole;
	}


	public Integer getUserId() {
		return userId;
	}


	public void setUserId(Integer userId) {
		this.userId = userId;
	}


	public String getuName() {
		return uName;
	}


	public void setuName(String uName) {
		this.uName = uName;
	}


	public String getuEamil() {
		return uEamil;
	}


	public void setuEamil(String uEamil) {
		this.uEamil = uEamil;
	}


	public String getuPassword() {
		return uPassword;
	}


	public void setuPassword(String uPassword) {
		this.uPassword = uPassword;
	}


	public String getuRole() {
		return uRole;
	}


	public void setuRole(String uRole) {
		this.uRole = uRole;
	}


	@Override
	public String toString() {
		return "User [userId=" + userId + ", uName=" + uName + ", uEamil=" + uEamil + ", uPassword=" + uPassword
				+ ", uRole=" + uRole + "]";
	}
	
	

}
