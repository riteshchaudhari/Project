package pojos;

public class Book {
	
	private Integer bookId;
	private String bTitle;
	private String bIsbn;
	private String bAuthor;
	private Category category;
	
	public Book() {
	}

	public Book(String bTitle, String bIsbn, String bAuthor, Category category) {
		super();
		this.bTitle = bTitle;
		this.bIsbn = bIsbn;
		this.bAuthor = bAuthor;
		this.category = category;
	}

	public Book(Integer bookId, String bTitle, String bIsbn, String bAuthor, Category category) {
		super();
		this.bookId = bookId;
		this.bTitle = bTitle;
		this.bIsbn = bIsbn;
		this.bAuthor = bAuthor;
		this.category = category;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getbTitle() {
		return bTitle;
	}

	public void setbTitle(String bTitle) {
		this.bTitle = bTitle;
	}

	public String getbIsbn() {
		return bIsbn;
	}

	public void setbIsbn(String bIsbn) {
		this.bIsbn = bIsbn;
	}

	public String getbAuthor() {
		return bAuthor;
	}

	public void setbAuthor(String bAuthor) {
		this.bAuthor = bAuthor;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bTitle=" + bTitle + ", bIsbn=" + bIsbn + ", bAuthor=" + bAuthor
				+ ", category=" + category + "]";
	}
	
}
