package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBManager 
{
	static String driver = "com.mysql.jdbc.Driver";
	static String url = "jdbc:mysql://localhost:3306/book_review_sys";
	static String uname = "root";
	static String password = "root";
    
    public static Connection getConnection()
    {
    	Connection connection = null;
    	try 
    	{
    		Class.forName(driver);
    		connection = DriverManager.getConnection(url, uname, password);
    	}
    	catch (ClassNotFoundException | SQLException e) 
    	{
    		e.printStackTrace();
    	}
    	return connection;
    }
}
