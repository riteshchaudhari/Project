package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pojos.Book;
import pojos.Category;
import pojos.Review;
import pojos.User;

public class UserDao {
	
	private Connection connection = DBManager.getConnection();
	
	public List<Book> getBooksByTitle(String title){
		
		List<Book> bookList = new ArrayList<>();
		
		try {
			ResultSet resultSet =  connection.createStatement()
					.executeQuery("SELECT * FROM book_review_sys.books b, book_review_sys.category c "
							+ "where b.CategoryId = c.CategoryId and  b.BTitle like '%" + title + "%'");
			while(resultSet.next())
			{
				Book book = new Book();
				book.setBookId(resultSet.getInt(1));
				book.setbTitle(resultSet.getString(2));
				book.setbIsbn(resultSet.getString(3));
				book.setbAuthor(resultSet.getString(4));
				book.setCategory(new Category(resultSet.getInt(5), resultSet.getString(7)));
				
				//adding book to bookList
				bookList.add(book);
				
			}//while end
			
		} catch (SQLException e) {
			e.printStackTrace();
		}//try-catch end
		
		return bookList;
	}//getBooksByTitle end
	
	public List<Book> getBooksByAuthor(String author){
		
		List<Book> bookList = new ArrayList<>();
		try {
			//Retrieving Data from Db and string it to BookList
			ResultSet resultSet =  connection.createStatement()
					.executeQuery("SELECT * FROM book_review_sys.books b, book_review_sys.category c "
							+ "where b.CategoryId = c.CategoryId and  b.BAuthor like '%" + author + "%'");
			while(resultSet.next())
			{
				Book book = new Book();
				book.setBookId(resultSet.getInt(1));
				book.setbTitle(resultSet.getString(2));
				book.setbIsbn(resultSet.getString(3));
				book.setbAuthor(resultSet.getString(4));
				book.setCategory(new Category(resultSet.getInt(5), resultSet.getString(7)));
				
				//adding book to bookList
				bookList.add(book);
			}//while end
			
		} catch (SQLException e) {
			e.printStackTrace();
		}//try-catch end
		
		return bookList;
	}//getBooksByAuthor end
	
	public List<Category> getCategoryList()
	{
		List<Category> catList = new ArrayList<>();
		
		try {
			//Retrieving Data from Db and string it to BookList
			ResultSet resultSet =  connection.createStatement()
					.executeQuery("SELECT * FROM book_review_sys.category");
			while(resultSet.next())
			{
				Category categor = new Category(resultSet.getInt(1), resultSet.getString(2));
				
				//Adding category to list
				catList.add(categor);
				
			}//while end
			
		} catch (SQLException e) {
			e.printStackTrace();
		}//try-catch end
		
		return catList;
	}//getCategoryList end
	
	public List<Book> getBooksByCategory(Integer categoryId){
		
		List<Book> bookList = new ArrayList<>();
		try {
			ResultSet resultSet =  connection.createStatement()
					.executeQuery("SELECT * FROM book_review_sys.books b, book_review_sys.category c "
							+ "where b.CategoryId = c.CategoryId and  b.CategoryId=" + categoryId);
			while(resultSet.next())
			{
				Book book = new Book();
				book.setBookId(resultSet.getInt(1));
				book.setbTitle(resultSet.getString(2));
				book.setbIsbn(resultSet.getString(3));
				book.setbAuthor(resultSet.getString(4));
				book.setCategory(new Category(resultSet.getInt(5), resultSet.getString(7)));
				
				//adding book to bookList
				bookList.add(book);
				
			}//while end
			
		} catch (SQLException e) {
			e.printStackTrace();
		}//try-catch end
		
		return bookList;
	}//getBooksByCategory end
	
	public List<Review> getBookReviews(Book book){
		
		List<Review> reviewList = new ArrayList<>();
		
		try {
			ResultSet resultSet =  connection.createStatement()
					.executeQuery("SELECT * FROM book_review_sys.reviews r, book_review_sys.users u where r.UserId = u.UserId and r.BookId=" + book.getBookId());
			while(resultSet.next())
			{
				User user = new User(resultSet.getInt(5), resultSet.getString(6), resultSet.getString(7), resultSet.getString(8), resultSet.getString(9));
				Review review = new Review(resultSet.getInt(1), book, user, resultSet.getString(4));

				//adding book to bookList
				reviewList.add(review);
				
			}//while end
			
		} catch (SQLException e) {
			e.printStackTrace();
		}//try-catch end
		
		return reviewList;
	}//getBookReviews end
	
	public boolean addReview(Review review){
		
		try {
			PreparedStatement statement =  connection.prepareStatement("INSERT INTO book_review_sys.reviews (BookId, UserId, Review)"
					+ "values(?,?,?)");
			statement.setInt(1, review.getBook().getBookId());
			statement.setInt(2, review.getUser().getUserId());
			statement.setString(3, review.getReview());
			
			int rowsAffected = statement.executeUpdate();
			if(rowsAffected > 0)
				return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
}
