package controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Authenticate;
import pojos.User;


@WebServlet("/Login")

public class LogIn extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Authenticate authenTicate=new Authenticate();
	   
   public LogIn() {
        super();

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{				
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		
		User user=new User();
		response.setContentType("text/html");    
		
			String email=request.getParameter("email");
			String pass=request.getParameter("password");
			user.setuEamil(email);
			user.setuPassword(pass);
			
			user =authenTicate.authorise(user);
			
			System.out.println(user);
			
			if(user != null){
				if(user.getuRole().equalsIgnoreCase("Admin"))
				{
					session.setAttribute("user", user);	
					request.getRequestDispatcher("AdminHomeTemplate.jsp").forward(request, response);
									
				}
				else if(user.getuRole().equalsIgnoreCase("User"))
				{
					//RequestDispatcher requestDispatcher =request.getRequestDispatcher("UserHome.jsp");
					session.setAttribute("user", user);
					response.sendRedirect("UserHome.jsp");
					//requestDispatcher.forward(request, response);
					
				}
				
			}//if end
			else {
				request.setAttribute("errorMessage", "UserName or Password Incorrect!");
				request.getRequestDispatcher("Login.jsp").forward(request, response);
			}
		
		doGet(request, response);
	}

}
