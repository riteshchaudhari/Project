package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDao;
import pojos.Book;
import pojos.Review;
import pojos.User;

/**
 * Servlet implementation class BookReviewController
 */
@WebServlet("/BookReviewController")
public class BookReviewController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private UserDao dao = new UserDao();
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookReviewController() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		//Checking for a Valid Session
		if(session.getAttribute("user") != null){
			Integer bookId;
			
			String view = request.getParameter("select");
			
			//Get ReviewText
			String reviewText = request.getParameter("reviewText");
			
			System.out.println("view : " + view);
		
			//Showing Book Details 
			if(view != null && view.equalsIgnoreCase("View Details")){
				
				System.out.println("View If.......");
				
				bookId = Integer.parseInt(request.getParameter("BookId"));
				
				Book book = null;
				List<Book> bookList = (List<Book>)session.getAttribute("bookList");
				
				//Check for Book List is not empty
				if(bookList != null){
					//Searching the required book
					for (Book book1 : bookList) {
						if(book1.getBookId() == bookId)
							book = book1;
					}//for-each end
					
				if(book != null){
					System.out.println(book);
					session.setAttribute("book", book);
					
					//Get all Reviews of user Selected Book
					List<Review> reviewList = dao.getBookReviews(book);
					
					//Adding review List to session Scope
					if(!reviewList.isEmpty())
						session.setAttribute("reviewList", reviewList);
					else
						session.setAttribute("reviewList", "");
					
					
					request.getRequestDispatcher("AddReview.jsp").forward(request, response);
					}//if end
					
				}//if end
				
				
			}//if end
			
			else if(reviewText != null){
				System.out.println("View Else If.......");
				
				bookId = Integer.parseInt(request.getParameter("BookId"));
				Review review = new Review((Book)session.getAttribute("book"),
						(User)session.getAttribute("user"), reviewText);
				
				if(dao.addReview(review)){
					System.out.println("review Added Successfully");
					
					//request.setAttribute("reviewText", "");
					//request.setAttribute("select", "View Details");
					response.sendRedirect("BookReviewController?BookId=" + bookId + "&select=View+Details");
					//request.getRequestDispatcher("BookReviewController").forward(request, response);
					//response.sendRedirect("BookReview.jps");
				}
				
			}//else if end
			
			
		}//Session Checking if end
		else{
			response.sendRedirect("Login.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
