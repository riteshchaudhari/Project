package controller;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AdminDao;

/**
 * Servlet implementation class RemoveBook
 */
@WebServlet("/RemoveBook")
public class RemoveBook extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	AdminDao adminDao = new AdminDao();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveBook() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Enumeration<String> enums = request.getParameterNames();
		String str = null;
		int result = 0;
		while(enums.hasMoreElements())
		{
			str = enums.nextElement();
		}
		
		if(str.equals("title"))
		{
			String title = request.getParameter("title");
			result = adminDao.RemoveByTitle(title);
		}
		if(str.equals("isbn"))
		{
			String isbn = request.getParameter("isbn");
			result = adminDao.RemoveByTitle(isbn);
		}
		
		if(result == 1)
		{
			
			request.setAttribute("status","Record deleted Sucessfully!");
			request.getRequestDispatcher("AdminHomeTemplate.jsp").forward(request, response);
		}
		else
		{		
			request.setAttribute("status","Book entry does not exist..!");
			request.getRequestDispatcher("RemoveBook.jsp").forward(request, response);
		}
	}

}
